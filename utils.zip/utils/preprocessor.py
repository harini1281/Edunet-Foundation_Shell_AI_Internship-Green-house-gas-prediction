import pandas as pd
def preprocess_input(df):
    substance_mapping = {'carbon dioxide': 0, 'methane': 1, 'nitrous oxide': 2, 'other GHGs': 3}
    unit_mapping = {'kg/2018 USD, purchaser price': 0, 'kg CO2e/2018 USD, purchaser price': 1}
    source_mapping = {'Commodity': 0, 'Industry': 1}

    df['Substance'] = df['Substance'].map(substance_mapping)
    df['Unit'] = df['Unit'].map(unit_mapping)   
    df['Source'] = df['Source'].map(source_mapping)
    return df